<?php
error_reporting(E_ALL ^ E_NOTICE)
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title> Student Registation Page </title>
	<meta charset="utf_8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.jx"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstap.min.js"></script>
</head>
<body>
<?php include 'master.php';?>

	<div class="container text-center" style="color:Blue">
	<h1>Welcome to the Registration Page</h1>
	</div>

<?php require('config.php');?>


<form align="center"  method = "POST" action="registeruser.php">
<h4><center>
	<form method="post" action="includes/registration.inc.php">
	<input type="text" name="firstName" placeholder="Enter First Name">
	<input type="text" name="lastName" placeholder="Enter Last Name"><br><br>
	<input type="text" name="email" placeholder="Enter Email">
	<input type="text" name="phone" placeholder="Enter Phone Number"><br><br>
	<input type="text" name="address" placeholder="Enter Address"><br><br>
	<input type="text" name="degree" placeholder="Enter Degree">
	<input type="password" name="password" placeholder="Enter Password"><br><br>
	<button type="submit" class="btn" name="save">Submit</button>
</h4>


	
	</fieldset>
</form>



</br>
</br>
</br>



	
<?php include 'footer.php';?>
</body>
</html>
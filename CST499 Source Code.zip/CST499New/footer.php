<?php
error_reporting(E_ALL ^ E_NOTICE)
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf_8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.jx"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstap.min.js"></script>
</head>
<body>

<div calss="navbar-fixed-bottom row-fluid">
	<div class="navbar-inner">
		<div class="container text-center">
			Copyright @ 2023 - Caleb Drehmer
		</div>
	</div>
</div>

</body>
</html>
